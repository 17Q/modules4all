# script.module.urlresolver

URLResolver Development for the Kodi Media Center - Kodi is a registered trademark of the XBMC Foundation. We are not connected to or in any other way affiliated with Kodi - DMCA: legal@tvaddons.co